import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from "@angular/router";

import { AppComponent } from './app.component';
import { PipeComponent } from './pipe/pipe.component';
import { SalaryTaxPipe } from './salary-tax.pipe';
import { UserListComponent } from './user-list/user-list.component';
import { Parent1Component } from './comp-interaction/parent1/parent1.component';
import { Child1Component } from './comp-interaction/child1/child1.component';
import { Parent2Component } from './comp-interaction/parent2/parent2.component';
import { Child2Component } from './comp-interaction/child2/child2.component';
import { Child3Component } from './comp-interaction/child3/child3.component';
import { Parent3Component } from './comp-interaction/parent3/parent3.component';
//import { Route } from '@angular/compiler/src/core';
import { PageNotFoundComponent } from './comp-interaction/page-not-found/page-not-found.component';
import { FormComponent } from './form/form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';

const routes: Routes = [
  { path: 'form', component: FormComponent },
  { path: 'home', component: UserListComponent },
  { path: 'p2c', component: Parent1Component },
  { path: 'c2p1', component: Parent2Component },
  { path: 'c2p2', component: Parent3Component },
  { path:'rforms', component: ReactiveFormComponent },
  //{ path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    PipeComponent,
    SalaryTaxPipe,
    UserListComponent,
    Parent1Component,
    Child1Component,
    Parent2Component,
    Child2Component,
    Child3Component,
    Parent3Component,
    PageNotFoundComponent,
    FormComponent,
    ReactiveFormComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
