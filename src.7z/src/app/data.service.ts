import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  path = "https://jsonplaceholder.typicode.com/";
  constructor(private http: HttpClient) { }
  getUsers() {
    return this.http.get(this.path + 'users');
  }
  getUserById(id: number): Observable<any> {
    return this.http.get(this.path + 'users/' + id);
  }
  addUser(user): Observable<any> {
    return this.http.post(this.path + 'users/', user);
  }
  updateUser(user): Observable<any> {
    return this.http.put(this.path + 'users/' + user.id, user);
  }
  deleteUser(id): Observable<any> {
    return this.http.delete(this.path + '/users/' + id);
  }
}
