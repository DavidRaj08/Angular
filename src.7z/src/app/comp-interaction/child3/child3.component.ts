import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css']
})
export class Child3Component {

  message: string = 'Message from Child';
  @Output() messageEvent= new EventEmitter<string>();
  sendMessage(){

    this.messageEvent.emit(this.message);
  }

}
