export interface User {
    name: string;
    username: string;
    id: number;
    email: string;
    website: string;
}
