import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SampleService {
  getMessage(): string {
    return 'Message from Service'
  }
}
