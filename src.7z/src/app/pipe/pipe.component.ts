import { Component } from '@angular/core';
import { Employee } from '../entities/employee';
import { SampleService } from '../sample.service'

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent {
 value: string;
  constructor(private service: SampleService) {
    this.value = this.service.getMessage();
    
    this.empList = [
      { firstName: 'Jason', lastName: 'Statham', salary: 35000, doj: '2019-05-20' },
      { firstName: 'Dwayne', lastName: 'Johnson', salary: 25485, doj: '2018-01-15' },
      { firstName: 'Vin', lastName: 'Diesel', salary: 87964, doj: '2016-04-11' },
      { firstName: 'Chris', lastName: 'Patt', salary: 44188, doj: '2017-02-11' }
    ];
    console.log(this.empList)
  }

  show = false;
  empList: Employee[];
  
}
