import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'salaryTax'
})
export class SalaryTaxPipe implements PipeTransform {

  transform(salary: number, tax: number=2): any {
    return (salary-(salary * tax / 100));
  }

}
